test1.R		Main test file, uses:
		  do.test.t
		  createObjects.t
		  useObjects.t
		  allTrue.t
		  all.equal.excluding.t
test2.R		Test handling of warnings and errors.
		  warnings.t
		  stops.t
